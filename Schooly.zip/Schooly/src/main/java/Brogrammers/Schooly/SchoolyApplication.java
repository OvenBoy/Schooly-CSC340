package Brogrammers.Schooly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolyApplication.class, args);
	}

}
