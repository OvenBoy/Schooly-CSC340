package com.schooly.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Schooly_run {

	public static void main(String[] args) {
		SpringApplication.run(Schooly_run.class, args);
	}

}
